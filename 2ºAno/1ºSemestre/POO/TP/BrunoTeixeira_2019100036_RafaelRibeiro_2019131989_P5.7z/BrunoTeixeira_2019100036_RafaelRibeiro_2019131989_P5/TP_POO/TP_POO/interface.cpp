#include "interface.h"
#include <fstream>

using namespace std;


Interface::Interface()
{
}


Interface::~Interface()
{
}


int Interface::comeca() {
	string linha, comando;

	while (1) {
		
		cout << "Introduza um comando: ";
		getline(cin, linha);

		istringstream divide(linha);

		divide >> comando;
		veComando(comando, linha);
	}

	return 0;
}


void Interface::veComando(string comando, string linha) {
	
	if (comando == "avanca" || flag == 1) {
		flag = 1;
		modoJogo(linha);									
	}
	else {

		modoConfig(linha);
	}
}

void Interface::modoConfig(string linha) {
	string comando, tipo, aux;
	int n, contaArg = 0;

	istringstream divide(linha);
	istringstream divideAux(linha);

	divide >> comando >> tipo >> n;

	//verificar numero de argumentos
	while (divideAux >> aux) {
		++contaArg;
	}

	if (comando == "cria") {
		if (!tipo.empty() && n > 0 && contaArg == 3) {
			if (!logica.addTerritorio(tipo, n)) {
				cout << "[ERRO] territorio nao existe" << endl;
			}
		}
		else {
			cout << "[ERRO] no CRIA" << endl;
		}
	}	

	else if (comando == "carrega" && !tipo.empty() && contaArg == 2) {
		ifstream ficheiro(tipo);
		string ler;

		if (ficheiro.is_open()) {

			while (!ficheiro.eof()) {
				getline(ficheiro, ler);//ler cada linha do ficheiro e dividir a seguir

				if (ler.empty()) {
					cout << "[ERRO] ficheiro mal construdio, lido ate ao erro" << endl;
					return ;
				}

				istringstream divideFich(ler);		
				divideFich >> comando >> tipo >> n;//exemplo: cria planicie 2
					
				if (!logica.addTerritorio(tipo, n)) { 
					cout << "[ERRO] territorio nao existe" << endl;
				}
			}
			ficheiro.close();
		}
	}
	else if (comando == "carrega" && tipo.empty() && contaArg != 2) {
		cout << "[ERRO] carrega nome Ficheiro" << endl;
	}
	else if (comando == "lista") {
		if (!tipo.empty()) {
			cout << logica.infoTerritorio(tipo) << endl;
		}
		else {
			lista();
		}
	}
	else if (comando == "sair") {
		cout << "Aplicacao terminada!" << endl;
		exit(0);
	}
}


void Interface::modoJogo(string linha) {
	string comando, tipo;
	int n; //para a quantidade do modifica
	istringstream divide(linha);
	divide >> comando >> tipo >> n;

	if (comando == "conquista") {
		conquista(tipo);
	}
	else if (comando == "passa") {
		passa();
		// comando ainda em constru��o
	}
	else if (comando == "maisouro") {
		maisOuro();
		// comando ainda em constru��o
	}
	else if (comando == "maisprod") {
		maisProd();
		// comando ainda em constru��o
	}
	else if (comando == "maismilitar") {
		maisMilitar();
		// comando ainda em constru��o
	}
	else if (comando == "adquire") {
		adquire();
		// comando ainda em constru��o
	}
	else if (comando == "lista") {
		if (!tipo.empty()) {
			cout << logica.infoTerritorio(tipo) << endl;
		}
		else {
			lista();
		}
	}
	else if (comando == "avanca") {
		cout << "Entrou no modo jogo" << endl;
		avanca();

	}
	else if (comando == "grava") {
		grava();
		// comando ainda em constru��o
	}
	else if (comando == "ativa") {
		ativa();
		// comando ainda em constru��o
	}
	else if (comando == "apaga") {
		apaga();
		// comando ainda em constru��o
	}
	else if (comando == "toma") {
		toma();
		// comando ainda em constru��o
	}
	else if (comando == "modifica") { // fun��o DEBUG
		if (!tipo.empty() && n > 0) {
			modifica(tipo, n);
		}

	}
	else if (comando == "fevento") {
		fEvento();
		// comando ainda em constru��o
	}
	else if (comando == "sair") {
		cout << "Aplicacao terminada!" << endl;
		exit(0);
	}
	else if (comando == "carrega" || comando == "cria") {		//pode entrar no mJogo mesmo com um comando cria ou carrega, caso j� tenhamos entrado no mJogo anteriormente (por causa da flag)
		cout << "[ERRO] ja nao e possivel configurar!" << endl;
		return;			
	}
	else {
		cout << "[ERRO] comando nao existente para jogar" << endl;
		return;
	}

}

void Interface::conquista(string tipo) {
	
	if (!logica.conqTerritorio(tipo)) {
		cout << "Territorio nao existe no Mundo" << endl;
	}

	//logica.recolheRecursos(); // ainda em construcao

}

void Interface::passa()const {
	//cout << "falta implementar" << endl;
}

void Interface::maisOuro()const {
	//cout << "comando ainda em construcao" << endl;

}

void Interface::maisProd()const {
	//cout << "comando ainda em construcao" << endl;
}

void Interface::maisMilitar()const {
	//cout << "comando ainda em construcao" << endl;

}

void Interface::adquire()const {
	//cout << "comando ainda em construcao" << endl;

}

void Interface::lista() {
	cout << "======================================================================"
		<< endl <<"Informacao sobre o mundo: " << endl << logica.infoTerrMundo() << endl
		<< "Informacao sobre o imperio: " << endl << logica.infoTerrImp() 
		<< "======================================================================" << endl;
}

void Interface::avanca()const {
	//cout << "falta implementar" << endl;
}

void Interface::grava()const {
	//cout << "comando ainda em construcao" << endl;
}

void Interface::ativa()const {
	//cout << "comando ainda em construcao" << endl;

}

void Interface::apaga()const {
	//cout << "comando ainda em construcao" << endl;

}

void Interface::toma()const {
	//cout << "comando ainda em construcao" << endl;

}

void Interface::modifica(string tipo, int n) {
	if (!logica.modificaDados(tipo, n)) {
		cout << "[ERRO]Tipo inv�lido (ouro ou prod + quantidade)" << endl;
	}
	else {
		cout << "[DEBUG]Aumentou " << n << " de " << tipo << endl;
	}
	
}

void Interface::fEvento()const {
	//cout << "comando ainda em construcao" << endl;
}
