#ifndef CONTINENTE_H
#define CONTINENTE_H
#include "territorio.h"

using namespace std;

class Continente :
	public Territorio
{
public:

	Continente();
	~Continente();
};



#endif // !CONTINENTE_H

/*Continente deriva de territorio*/