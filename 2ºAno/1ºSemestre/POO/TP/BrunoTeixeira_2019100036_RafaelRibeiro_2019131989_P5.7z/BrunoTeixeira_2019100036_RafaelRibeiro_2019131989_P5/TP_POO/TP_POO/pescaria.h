#ifndef PESCARIA_H
#define PESCARIA_H
#include <string>
#include <sstream>
#include "ilha.h"

class Pescaria:
	public Ilha
{
	/*
	int prod_primeiro;
	int prod_segundo;*/
	static int numT;
public:
	void recolher(int ano, int turno, int *ouro, int *prod);
	string getAsString()const;

	static const string nome_princ;
	string getNomePrinc()const { return nome_princ; }


	Pescaria();
	~Pescaria();
};


#endif // !PESCARIA_H


