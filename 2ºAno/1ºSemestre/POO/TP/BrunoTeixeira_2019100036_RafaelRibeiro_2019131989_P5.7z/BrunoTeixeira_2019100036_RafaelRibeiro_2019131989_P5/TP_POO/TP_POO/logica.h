#ifndef LOGICA_H
#define LOGICA_H
#include <string>
#include <sstream>
#include "mundo.h"
#include "terrnic.h"
#include "territorio.h"
#include "planicie.h"
#include "castelo.h"
#include "duna.h"
#include "fortaleza.h"
#include "mina.h"
#include "montanha.h"
#include "refpiratas.h"
#include "pescaria.h"
#include "imperio.h"

using namespace std;

class Logica
{

	Mundo *mundo; // aqui ficam os territorios a serem conquistados
	Imperio *imperio; // aqui fica o meu territorio inicial e o meu imperio
public:
	bool addTerritorio(string tipo, int quantidade); // add Territorios ao mundo (com os comandos "cria" e "carrega")
	bool conqTerritorio(string nome); // conqTerritorios serve para conquistar Territorios(com o comando "conquista")
	bool modificaDados(string tipo, int quantidade);  //modifica a quantidade de ouro ou produtos [DEBUG]
	//bool recolheRecursos(); em construcao


	string infoTerrImp(); // informacao do imperio
	string infoTerrMundo(); // informacao do mundo
	string infoTerritorio(string nome);	// informa��o de um territorio

	Logica();
	~Logica();
};

#endif