#include "ilha.h"



Ilha::Ilha()
{
}


Ilha::~Ilha()
{
}
