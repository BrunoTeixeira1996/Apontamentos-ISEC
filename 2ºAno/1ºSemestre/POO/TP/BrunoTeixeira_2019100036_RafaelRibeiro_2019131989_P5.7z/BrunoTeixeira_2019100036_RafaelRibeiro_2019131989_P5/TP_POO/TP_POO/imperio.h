#ifndef IMPERIO_H
#define IMPERIO_H
#include <vector>
#include <string>
#include <sstream>
#include "territorio.h"
#include "terrnic.h"

using namespace std;

class Imperio
{
	int cofre = 0;
	int armazem = 0;
	int forca_militar = 1;
	int pontos_vitoria = 0;
	int sorte = 0;

	vector<Territorio*> territorios;
public:
	vector<Territorio*> getImperio() { return territorios ;}

	//sets
	bool insereTerritorio(Territorio* t);
	void decMilitar() {--forca_militar; }
	void setPontosVitoria(Territorio* t);
	void setOuroDebug(int n) { cofre = n; }
	void setProdDebug(int n) { armazem = n; }
	//bool setRecolher(int ano, int turno); em construcao

	//gets
	int getCofre()const { return cofre; }
	int getArmazem()const { return armazem; }
	int getMilitar()const { return forca_militar; }
	int getFSorte(); // devolve o fator sorte entre 1-6 + forca_militar
	int getPontosVitoria()const { return pontos_vitoria; }
	int getSorte()const { return sorte; }
	string getAsString()const;


	Imperio();
	~Imperio();
};



#endif // !1

