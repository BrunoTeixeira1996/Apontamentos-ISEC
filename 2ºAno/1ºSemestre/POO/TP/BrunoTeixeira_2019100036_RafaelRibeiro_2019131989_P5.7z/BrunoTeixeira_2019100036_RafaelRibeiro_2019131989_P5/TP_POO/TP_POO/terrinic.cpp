#include "terrnic.h"



TerrInic::TerrInic()
{
	setNome("TerritorioInicial");
	setResistencia(9);
	setOuro(1);
	setProduto(1);
}


TerrInic::~TerrInic()
{
}

void TerrInic::recolher(int ano, int turno, int *ouro, int *prod) {
	return;

}
string TerrInic::getAsString()const {
	ostringstream os;

	os << Territorio::getAsString();

	return os.str();
}
