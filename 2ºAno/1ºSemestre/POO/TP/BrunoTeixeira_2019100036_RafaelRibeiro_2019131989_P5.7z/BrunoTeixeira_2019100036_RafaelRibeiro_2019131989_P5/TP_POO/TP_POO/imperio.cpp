#include "imperio.h"



Imperio::Imperio()
{
	territorios.push_back(new TerrInic());
}


Imperio::~Imperio()
{
	// limpa os ponteiros do vector territorios
	for (auto i : territorios) {
		delete i;
	}
	territorios.clear();
}


int Imperio::getFSorte() {
	srand((unsigned int)time(NULL));

	int f_sorte = (rand() % 5 + 1) + forca_militar;
	sorte = f_sorte;

	return f_sorte;
}

bool Imperio::insereTerritorio(Territorio* t) {
	territorios.push_back(t);
	return true;
}


string Imperio::getAsString()const {
	ostringstream os;

	os << "Ouro no cofre: " << cofre << " Produtos no armazem: " << armazem
		<< " Forca militar: " << forca_militar << " Pontos de vitoria: " << pontos_vitoria
		<< " Fator sorte: " << sorte;

	return os.str();

}


void Imperio::setPontosVitoria(Territorio* t) {
	if (t->getTipo() == "Ilha") {
		pontos_vitoria += 2;
	}
	else {
		pontos_vitoria += 1;
	}
}



// em construcao
//bool Imperio::setRecolher(int ano, int turno) {
//
//	for (Territorio *t : territorios) {
//		if(armazem < 3 && cofre < 3)
//			t->recolher(ano, turno, &cofre, &armazem);
//	}
//
//	return true;
//}
