#ifndef PLANICIE_H
#define PLANICIE_H
#include <string>
#include <sstream>
#include "continente.h"

using namespace std;

class Planicie:
	public Continente
{
	//int prod_primeiro;
	//int ouro_primeiro;
	//int prod_segundo;
	//int ouro_segundo;
	static int numT;
public:
	void recolher(int ano, int turno, int *ouro, int *prod);
	string getAsString()const;

	static const string nome_princ;
	string getNomePrinc()const { return nome_princ; }

	Planicie();
	~Planicie();
};

#endif // !PLANICIE_H

