#include "mundo.h"

Mundo::Mundo()
{
}


Mundo::~Mundo()
{
	// limpa os ponteiros do vector territorio
	for (auto i : territorio) {
		delete i;
	}
	territorio.clear();
}

bool Mundo::novoTerritorio(Territorio *t) {
	territorio.push_back(t);
	return true;
}


bool Mundo::veTerritorio(string nome) {

	for (Territorio* ie : territorio) {
		if (nome == ie->getNome())
		{
			return true;
		}
	}
	return false;
}

Territorio* Mundo::retornaTerritorio(string nome) {

	for (Territorio* ie : territorio) {
		if (nome == ie->getNome())
			return ie;
	}

	return nullptr;
}

bool Mundo::eliminaTerritorio(string nome) {

	vector<Territorio*>::iterator it;

	for (it = territorio.begin(); it != territorio.end(); it++) {
		if ((*it)->getNome() == nome) {
			it = territorio.erase(it);
			return true;
		}
	}

	return false;
}
