#include "continente.h"



Continente::Continente()
{
}


Continente::~Continente()
{
}
