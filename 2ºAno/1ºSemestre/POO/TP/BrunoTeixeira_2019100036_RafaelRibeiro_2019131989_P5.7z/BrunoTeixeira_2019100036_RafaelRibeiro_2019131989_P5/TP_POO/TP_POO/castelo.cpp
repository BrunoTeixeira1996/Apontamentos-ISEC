#include "castelo.h"

int Castelo::numT = 1;

const string Castelo::nome_princ = "Castelo";

Castelo::Castelo()
{

	setNome(nome_princ);
	setResistencia(1);
	setOuro(1);
	setProduto(1);
	setNumObj(numT++);
	//setNome("asd"); de ambas as maneiras
}


Castelo::~Castelo()
{
}

void Castelo::recolher(int ano, int turno, int *ouro, int *prod) {
	return;

}

string Castelo::getAsString()const {
	ostringstream os;


	os << Territorio::getAsString();

	return os.str();
}