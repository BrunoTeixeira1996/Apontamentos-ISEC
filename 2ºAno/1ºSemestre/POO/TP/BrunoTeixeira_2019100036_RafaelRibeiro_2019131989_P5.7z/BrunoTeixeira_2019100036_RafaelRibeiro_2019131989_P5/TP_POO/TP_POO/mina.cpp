#include "mina.h"

int Mina::numT = 1;

const string Mina::nome_princ = "Mina";

Mina::Mina()
{
	setNome(nome_princ);
	setResistencia(1);
	setOuro(1);
	setProduto(1);
	setNumObj(numT++);
}


Mina::~Mina()
{
}

void Mina::recolher(int ano, int turno, int *ouro, int *prod) {
	return ;
}

string Mina::getAsString()const {
	ostringstream os;


	os << Territorio::getAsString();

	return os.str();
}