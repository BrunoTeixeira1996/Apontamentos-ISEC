#include <iostream>
#include <string>
#include <sstream>
#include <fstream>
#include "interface.h"
#include "logica.h"

using namespace std;

int main() {

	Interface inter;

	inter.comeca();

	return 0;
}