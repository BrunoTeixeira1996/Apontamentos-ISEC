#include "refpiratas.h"

int RefPiratas::numT = 1;

const string RefPiratas::nome_princ = "Refugio dos Piratas";

RefPiratas::RefPiratas()
{
	setNome(nome_princ);
	setTipo("Ilha");
	setResistencia(1);
	setOuro(1);
	setProduto(1);
	setNumObj(numT++);
}


RefPiratas::~RefPiratas()
{
}

void RefPiratas::recolher(int ano, int turno, int *ouro, int *prod) {
	return;

}

string RefPiratas::getAsString()const {
	ostringstream os;


	os << Territorio::getAsString();

	return os.str();
}