#include "territorio.h"



Territorio::Territorio()
{
}


Territorio::~Territorio()
{
}

void Territorio::setNome(string n) {
	nome = n;
	if (numObj != 0) {
		nome += to_string(numObj);
	}
}

void Territorio::setNumObj(int num) {
	numObj = num; 
	if (nome.empty()) {

		nome = getNomePrinc() + to_string(numObj);
	}
	else {
		nome += to_string(numObj);
	}
}

string Territorio::getAsString()const {
	ostringstream os;

	os << nome << " / " ;

	return os.str();
}