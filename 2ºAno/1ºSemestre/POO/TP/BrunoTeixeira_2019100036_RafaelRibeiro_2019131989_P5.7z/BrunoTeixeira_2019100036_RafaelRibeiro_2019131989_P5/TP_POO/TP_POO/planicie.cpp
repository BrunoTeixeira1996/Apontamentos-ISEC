#include "planicie.h"

int Planicie::numT = 1;

const string Planicie::nome_princ = "Planicie";

Planicie::Planicie()
{
	setNome(nome_princ);
	setResistencia(1);
	setOuro(1);
	setProduto(1);
	setNumObj(numT++);
}


Planicie::~Planicie()
{
}

void Planicie::recolher(int ano, int turno, int *ouro, int *prod) {
	return;

}

string Planicie::getAsString()const {
	ostringstream os;


	os << Territorio::getAsString();

	return os.str();
}