#include "pescaria.h"

int Pescaria::numT = 1;

const string Pescaria::nome_princ = "Pescaria";

Pescaria::Pescaria()
{
	setNome(nome_princ);
	setTipo("Ilha");
	setResistencia(1);
	setOuro(1);
	setProduto(1);
	setNumObj(numT++);
}


Pescaria::~Pescaria()
{
}

void Pescaria::recolher(int ano, int turno, int *ouro, int *prod) {
	return;

}

string Pescaria::getAsString()const {
	ostringstream os;


	os << Territorio::getAsString();

	return os.str();
}