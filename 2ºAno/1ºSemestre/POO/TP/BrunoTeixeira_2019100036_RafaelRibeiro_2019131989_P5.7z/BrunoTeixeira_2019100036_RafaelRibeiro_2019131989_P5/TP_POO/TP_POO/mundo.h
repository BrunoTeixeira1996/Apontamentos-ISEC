#ifndef  MUNDO_H
#define MUNDO_H
#include <vector>
#include <string>
#include <sstream>
#include "territorio.h"

using namespace std;

class Mundo
{
	vector<Territorio*>territorio;
public:

	//get
	vector<Territorio*>getMundo() { return territorio; }
	bool veTerritorio(string nome); // verifica se um certo dado Territorio(nome) existe no vector territorio

	Territorio* retornaTerritorio(string nome); // retorna um ponteiro do tipo Territorio 

	// set
	bool novoTerritorio(Territorio* t);
	bool eliminaTerritorio(string nome);

	
	Mundo();
	~Mundo();
};


#endif // ! MUNDO_H


