#ifndef INTERFACE_H
#define INTERFACE_H
#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include "logica.h"

using namespace std;


class Interface
{
	Logica logica;
	int flag = 0;		//para constrolar quando estamos no modoJogo
public:
	Interface();
	~Interface();

	/*Preparacao*/
	int comeca(); // fun��o que inicia o programa
	void veComando(string comando, string linha); //funcao que recebe comando e decide o modo
	void modoConfig(string linha); //funcao que recebe os comandos de config do jogo
	void modoJogo(string linha); // funcao que recebe os comandos de jogo

	/*Jogo*/
	void conquista(string tipo);
	void passa()const;
	void maisOuro()const;
	void maisProd()const;
	void maisMilitar()const;
	void adquire()const;
	void lista(); // informacao 
	void avanca()const;
	void grava()const;
	void ativa()const;
	void apaga()const;
	void toma()const;
	void modifica(string tipo, int n);
	void fEvento()const;

};

#endif