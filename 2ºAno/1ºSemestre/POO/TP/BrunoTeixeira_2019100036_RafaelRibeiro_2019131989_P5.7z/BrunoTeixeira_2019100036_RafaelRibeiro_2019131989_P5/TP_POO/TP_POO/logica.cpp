#include "logica.h"

Logica::Logica()
{
	imperio = new Imperio();
	mundo = new Mundo();
}


Logica::~Logica()
{
	delete mundo;
	delete imperio;
}

string Logica::infoTerrImp() {
	vector<Territorio*> info_imp;

	info_imp = imperio->getImperio();
	ostringstream os;

	os << imperio->getAsString() << endl;

	for (Territorio* imp : info_imp) {
		os << imp->getAsString();
	}
	os << endl;

	return os.str();
}

string Logica::infoTerrMundo() {
	vector<Territorio*> info_mundo;

	info_mundo = mundo->getMundo();
	ostringstream os;

	for (Territorio* ie : info_mundo) {
		os << ie->getAsString();
	}
	os << endl;
	return os.str();
}

string Logica::infoTerritorio(string nome) {
	ostringstream os;
	Territorio* p = nullptr;

	if (mundo->veTerritorio(nome) == true) {	
		p = mundo->retornaTerritorio(nome);
		os << "Nome: " << p->getNome() << " Resistencia: " << p->getResistencia() << " Ouro: " << p->getOuro()
			<< " Produto: " << p->getProduto() << endl;
	}
	else {
		os << "Territorio nao existe";
		// o Territorio est� no Imperio e nao no Mundo
	}

	return os.str();
}


bool Logica::addTerritorio(string tipo, int quantidade) {

	if (tipo == "castelo") {
		for (int i = 0; i < quantidade; i++) {
			mundo->novoTerritorio(new Castelo());
		}
		return true;
	}
	else if (tipo == "planicie") {
		for (int i = 0; i < quantidade; i++) {
			mundo->novoTerritorio(new Planicie());
		}
		return true;
	}
	else if (tipo == "montanha") {
		for (int i = 0; i < quantidade; i++) {
			mundo->novoTerritorio(new Montanha());
		}
		return true;
	}
	else if (tipo == "fortaleza") {
		for (int i = 0; i < quantidade; i++) {
			mundo->novoTerritorio(new Fortaleza());
		}
		return true;
	}
	else if (tipo == "mina") {
		for (int i = 0; i < quantidade; i++) {
			mundo->novoTerritorio(new Mina());
		}
		return true;
	}
	else if (tipo == "duna") {
		for (int i = 0; i < quantidade; i++) {
			mundo->novoTerritorio(new Duna());
		}
		return true;
	}
	else if (tipo == "refugio") {
		for (int i = 0; i < quantidade; i++) {
			mundo->novoTerritorio(new RefPiratas());
		}
		return true;
	}
	else if (tipo == "pescaria") {
		for (int i = 0; i < quantidade; i++) {
			mundo->novoTerritorio(new Pescaria());
		}
		return true;
	}

	return false;
	
}


bool Logica::conqTerritorio(string nome) {
	Territorio* p = nullptr;


	if (mundo->veTerritorio(nome) == true) { // verifica se o Territorio a ser conquistado existe no Mundo
		p = mundo->retornaTerritorio(nome); // o Ponteiro p fica apontar para o Territorio em quest�o
				
		if (imperio->getFSorte() >= p->getResistencia()) {	// verifica o fator sorte
			imperio->insereTerritorio(p);					//copiar o Territorio a ser conquistado para o Vector de Territorios do Imperio
			mundo->eliminaTerritorio(nome);					//eliminar do Vector de Territorios do Mundo o Territorio conquistado
			imperio->setPontosVitoria(p);					// pontos de vitoria (+1 se for Continente, +2 se for Ilha)
			return true;
		}
		else {												// se nao conseguiu conquistar
			if (imperio->getMilitar() > 0) {				// vai ver se a for�a militar <= 0
				imperio->decMilitar();						// se nao for, decrementa a for�a_miliar 
				return true;
			}

			exit(0); // termina o jogo
		}
	}
	else { //Territorio a ser conquistado nao existe no Mundo
		return false;
	}

}

bool Logica::modificaDados(string tipo, int quantidade) {
	if (tipo == "ouro") {
		imperio->setOuroDebug(quantidade);
		return true;
	}
	if(tipo == "prod") {
		imperio->setProdDebug(quantidade);
		return true;
	}
	return false;
}

//bool Logica::recolheRecursos() { // chamar esta funcao na interface
//	imperio->setRecolher(ano,turno);// recolhe ouro e prod
//
//	return true;
//}