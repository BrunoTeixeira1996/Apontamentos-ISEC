#include <stdlib.h>
#include <stdio.h>

int main(){
	printf("Welcome I'm the client\n");
	return 0;
}