Pequena aplicação feita em Flask para colmatar a TP de DD
